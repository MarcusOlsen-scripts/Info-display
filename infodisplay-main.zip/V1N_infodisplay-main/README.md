**V1N_infodisplay**

Hej, jeg vælger at udgive mit hud som viser penge i pungen og banken. Den viser også sorte penge og diverse vigtige informationer om din karakter.

Jeg har også fået en del henvendelser om at jeg har converteret scriptet, men det har jeg skam ikke, det er lavet fra bunden af, inspireret af Danish RP.

I configen kan du ændre 2 ting som er:
**Om hudded skal være åbent når du joiner**,
**Kommandoen for at toggle hudded!**

**Preview af scriptet.**
https://streamable.com/p6zeg4
